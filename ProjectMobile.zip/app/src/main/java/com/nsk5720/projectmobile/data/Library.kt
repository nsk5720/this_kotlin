package data

data class Library(
    val SeoulPublicLibraryInfo: SeoulPublicLibraryInfo
)