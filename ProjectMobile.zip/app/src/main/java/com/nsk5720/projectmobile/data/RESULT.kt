package data

data class RESULT(
    val CODE: String,
    val MESSAGE: String
)